Construye el fort.22 a partir de los ficheros con extensi�n .f0XX (XX es la hora Z de la observaci�n trihoraria) v�a wgrib2.exe

Para utilizarlo le indicas la ruta de wgrib2.exe y luego la indicas la ruta de la carpeta de ficheros con extensi�n .f0XX (XX es la hora Z de la observaci�n trihoraria), all� obtienes como resultado ficheros con extensi�n .csv, luego ficheros manipulados de datos con extensi�n .txt y el fichero fort.22 es la uni�n de los ficheros con extensi�n .txt

En la manipulaci�n para convertir a .txt se realiz� para obtener latitud en orden descendente y longitud en orden ascendente.